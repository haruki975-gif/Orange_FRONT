const PasswordForm = () => {
  return <></>;
};

export default PasswordForm;
