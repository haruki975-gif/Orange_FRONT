const ProfileImage = () => {
  return <></>;
};

export default ProfileImage;
