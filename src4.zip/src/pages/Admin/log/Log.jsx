import { useState } from "react";
import ManageLog from "./ManageLog";

const Log = () => {
    /* 로그인 기능 구현 예정 */
    
    return (
        <>
            <ManageLog />
        </>
    );
};

export default Log;